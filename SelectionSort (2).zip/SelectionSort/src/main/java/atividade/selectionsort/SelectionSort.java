package atividade.selectionsort;

public class SelectionSort {

    public static void main(String[] args) {

        int[] array = {5, 3, 8, 1, 4};
        
        System.out.print("Array Original:" );
        for(int num : array)
        {
            System.out.print(num + " ");
        }
        System.out.println("");
        
        
        selectionSort(array);
        System.out.print("Array Ordenado: ");
        for (int num : array) {
            System.out.print(num + " ");
        }
    }

    public static void selectionSort(int[] array) {

        for (int i = 0; i < array.length - 1; i++) {

            int smallestIndex = i;

            for (int j = i + 1; j < array.length; j++) {

                if (array[j] < array[smallestIndex]) {
                    smallestIndex = j;
                }
            }
            if (smallestIndex != i) {
                int temp = array[i];
                array[i] = array[smallestIndex];
                array[smallestIndex] = temp;
            }
        }
    }
}